[
    {
        "id": "Dialer",
        "bundleId": "com.apple.mobilephone",
        "activity": "PhoneApp",
        "firstObject": "//XCUIElementTypeButton[@name='Keypad']"
    },
    {
        "id": "TestAppId2",
        "bundleId": "com.test.iospackage",
        "activity": "MainViewController",
        "firstObject": "//*"
    }
]