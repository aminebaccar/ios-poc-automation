const hostname = '127.0.0.1';
const udid_device1 = 'RZCW40T95KW';
const udid_device2 = 'RZCT50KK07H';
const udid_device3 = '52002284eea2c411';

module.exports = {
  hostname,
  udid_device1,
  udid_device2,
  udid_device3
};